package com.example.preferences02;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
  EditText edt1,edt2,edt3,edt4;
  Button boto1, boto2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        edt1 = findViewById(R.id.edtcodigo);
        edt2 = findViewById(R.id.edtnombre);
        edt3 = findViewById(R.id.edtprecio);
        edt4 = findViewById(R.id.edtcantidad);
        boto1 = findViewById(R.id.btnregistrar);
        boto2 = findViewById(R.id.button_search);
    }
    public void Guardar(View view){

    String codigo = edt1.getText().toString();
    SharedPreferences preferences= getSharedPreferences(codigo,Context.MODE_PRIVATE);
    SharedPreferences.Editor edit = preferences.edit();
    edit.putString("codigo",codigo);
    edit.putString("nombre",edt2.getText().toString());
    edit.putString("precio",edt3.getText().toString());
    edit.putString("cantidad",edt4.getText().toString());
    edit.commit();

    }
    public void Buscar(View view){
        String codigo = edt1.getText().toString();
        SharedPreferences preferences = getSharedPreferences(codigo,Context.MODE_PRIVATE);
        SharedPreferences.Editor edit = preferences.edit();
        String nombre = preferences.getString("nombre"," ");
        String precio = preferences.getString("precio"," ");
        String cantidad = preferences.getString("cantidad"," ");
        edt2.setText(nombre);
        edt3.setText(precio);
        edt4.setText(cantidad);

    }

}